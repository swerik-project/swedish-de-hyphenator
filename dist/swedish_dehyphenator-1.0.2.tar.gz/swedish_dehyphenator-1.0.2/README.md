# Swedish de-hyphenator

A python program to remove end-line hyphenations from large texts.